// JavaScript Document

function reloadpage(pParam){
	location.reload(); 	
}

/* Begin Initializing */
function applychanges(pNewValue,pName,pTime){
	for(x=0;x<4;x++){
		$("#"+pNewValue).text($("#"+pName).val()+", "+$("#"+pTime).val()+" minutes"	
		);
	}
}

function ApplyAllChanges(){
	applychanges("1PName","txtFirstPlayerName","txtFirstPlayerTime");
	applychanges("2PName","txtSecondPlayerName","txtSecondPlayerTime");
	applychanges("3PName","txtThirdPlayerName","txtThirdPlayerTime");
	applychanges("4PName","txtFourthPlayerName","txtFourthPlayerTime");
}
/* End Initializing */

function Calculate(){
	var initial = [	
	  {time: +$("#txtFirstPlayerTime").val(), name: $("#txtFirstPlayerName").val(), 
     position: "1stFigure", passed: false},
		{time: +$("#txtSecondPlayerTime").val(), name: $("#txtSecondPlayerName").val(), 
     position: "2ndFigure", passed: false},
		{time: +$("#txtThirdPlayerTime").val(), name: $("#txtThirdPlayerName").val(), 
     position: "3rdFigure", passed: false},
		{time: +$("#txtFourthPlayerTime").val(), name: $("#txtFourthPlayerName").val(), 
     position: "4thFigure", passed: false}]	 		 
		 
		 LeastTime = FindMinimum(initial);
		 posMover1 = GetPosition(LeastTime, initial);
		 
		 timer = 0;
		 timeAccumulated = 0;		 		 
		 for(i=1;i<=5;i++){
			  if(i%2>0){
					setTimeout(function(){
					  MaxTime = FindMaximum(initial);
						posMover2 = GetPosition(MaxTime, initial);
						$("#"+initial[posMover1]["position"]).css({"left":"900px"});
						$("#"+initial[posMover2]["position"]).css({"left":"900px"});
						timeAccumulated+=MaxTime;									
						$("#timeCounter").text("Time: "+timeAccumulated+" minutes");
					},timer);										
				}else{					
					setTimeout(function(){				
						$("#"+initial[posMover1]["position"]).css({"left":"400px"});						
						timeAccumulated+=LeastTime;
						$("#timeCounter").text("Time: "+timeAccumulated+" minutes");
					},timer);				
				}								
				timer=IncreaseTimer(timer);
		 }
} 

function FindMinimum(pArray){
	topValue=10000000;
	
	for(x=0;x<4;x++){	
		if(+pArray[x]["time"]<topValue)
			topValue=+pArray[x]["time"];
	}
	return topValue;
}

function FindMaximum(pArray){
	bottomValue=-1;
	pos=0;
	for(x=0;x<4;x++){
		if(+pArray[x]["time"]>bottomValue && pArray[x]["passed"]==false){
			bottomValue=+pArray[x]["time"];
			pos=x;
			
		}
	}
	pArray[pos]["passed"]=true;
	return bottomValue;
}

function GetPosition(pValue, pArray){
	position=-1;
	for(x=0;x<4;x++){
		if(+pArray[x]["time"]==pValue)
			position=x;
	}
	return position;
}

function IncreaseTimer(pTimer){
	pTimer+=2000;
	return pTimer;
}