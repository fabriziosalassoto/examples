// JavaScript Document
//$(document){function(){
	//alert("hello");
//});


function removeOptions(selectbox){
    for(i=selectbox.options.length-1;i>=0;i--){
        selectbox.remove(i);
    }
}

function getdisciplines(preturnlist){	
	var myXML = loadXML();	
	var myDisciplines = myXML.getElementsByTagName("discipline");
	if(typeof preturnlist === "undefined" || preturnlist===null){
		fill_in_dropdownlists("drop_down_list1",myDisciplines);
	} else {
		return myDisciplines;		
	}
}

function getcategoriesbyID(pdiscipline_id, preturnlist){		
	if(typeof pdiscipline_id === "undefined" || pdiscipline_id===null){
		pdiscipline_id = +document.getElementById("drop_down_list1").selectedIndex;	
	}
	if(typeof preturnlist === "undefined" || preturnlist===null){
		preturnlist = false;
		removeOptions(document.getElementById("drop_down_list2"));
		removeOptions(document.getElementById("drop_down_list3"));
	} 
	displaydescription();
	var myDisciplines = getdisciplines(true);
	if(myDisciplines[pdiscipline_id].getElementsByTagName("id")[0].childNodes.length>0){
		var myCategories = myDisciplines[pdiscipline_id].getElementsByTagName("category");				
		if(!preturnlist){
			fill_in_dropdownlists("drop_down_list2",myCategories);										
		}else{
			return myCategories;
		}		
	}				
}

function getsubcategoriesbyID(pcategory_id, preturnlist){	
	if(typeof pdiscipline_id === "undefined" || pdiscipline_id===null){
		pcategory_id = +document.getElementById("drop_down_list2").selectedIndex;
	}
	if(typeof preturnlist === "undefined" || preturnlist===null){
		preturnlist = false;
		removeOptions(document.getElementById("drop_down_list3"));		
	}					
	displaydescription();
	var myCategories = getcategoriesbyID(+document.getElementById("drop_down_list1").selectedIndex,true);
	if(myCategories[pcategory_id].getElementsByTagName("id")[0].childNodes.length>0){
		var mySubCategories = myCategories[pcategory_id].getElementsByTagName("subcategory");		
		if(!preturnlist){			
			fill_in_dropdownlists("drop_down_list3",mySubCategories);							
		}else{
			return mySubCategories;
		}				
	}
}

function fill_in_dropdownlists(pdrop_down_list_name, poptions){
	for(var i = 0; i < poptions.length; i++){	
		if(poptions[i].getElementsByTagName("id")[0].childNodes.length>0){
			var myElementID = +poptions[i].getElementsByTagName("id")[0].childNodes[0].nodeValue;
		}else{
			var myElementID = i;
		}
		if(poptions[i].getElementsByTagName("name")[0].childNodes.length>0){
			var myElementName = poptions[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
		}else{
			var myElementName="";
		}
		var opt = document.createElement("option");       			        
		document.getElementById(pdrop_down_list_name).options.add(opt);
    	opt.text = myElementName;
	    opt.value = myElementID;
	}	
}

function loadXML(){
	var archivoXML="xml/combos.xml"; 
	var xmlDoc="";	
	
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlDoc=new XMLHttpRequest();					
	}else{// code for IE6, IE5
		xmlDoc=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlDoc.open("GET",archivoXML,false);
	xmlDoc.send();
	return xmlDoc.responseXML;
}

function displaydescription(){
	var vOption1="";
	var vOption2="";
	var vOption3="";
	if(document.getElementById('drop_down_list1').options[document.getElementById('drop_down_list1').selectedIndex].text!=""){
		vOption1="You have choosen: " + document.getElementById('drop_down_list1').options[document.getElementById('drop_down_list1').selectedIndex].text;
	}
	if(document.getElementById('drop_down_list2').options.length>0){
		if(document.getElementById('drop_down_list2').options[document.getElementById('drop_down_list2').selectedIndex].text!=""){
			vOption2=", "+document.getElementById('drop_down_list2').options[document.getElementById('drop_down_list2').selectedIndex].text;
		}
	}
	if(document.getElementById('drop_down_list3').options.length>0){
		if(document.getElementById('drop_down_list3').options[document.getElementById('drop_down_list3').selectedIndex].text!=""){
			vOption3=", "+document.getElementById('drop_down_list3').options[document.getElementById('drop_down_list3').selectedIndex].text;
		}
	}
	document.getElementById('msg').innerHTML = vOption1 + vOption2 + vOption3;
}