// JavaScript Document


function getdisciplines(preturnlist){	
	var myXML = loadXML();
	var myDisciplines = $(myXML).find("disciplines");	
	if($.type(preturnlist)=="undefined" || $.type(preturnlist)=="null" ){
		fill_in_dropdownlists("drop_down_list1",myDisciplines);
	}else{
		return myDisciplines;			
	}
}

function getcategoriesbyID(preturnlist){			
	var myDisciplines = getdisciplines(true);		
	var myCategories="";
	var pdiscipline_id=pdiscipline_id = $("#drop_down_list1").val();

	$(myDisciplines).find("discipline").each(function(){
		var myElementID = +$(this).find('id:first').text();
		if(myElementID==pdiscipline_id){
			myCategories = $(this).find('categories');
			if($.type(preturnlist)=="undefined" || 
			   $.type(preturnlist)=="null"){
				  $("#drop_down_list2").find("option").remove();
				  $("#drop_down_list3").find("option").remove();
				  fill_in_dropdownlists("drop_down_list2",myCategories);
			}
		}
	});
	displaydescription();
	return myCategories;			
}


function getsubcategoriesbyID(preturnlist){				
	var myCategories = getcategoriesbyID($("#drop_down_list1").val(),true);
	var mySubcategories = "";
	var pcategory_id=$("#drop_down_list2").val();

	$(myCategories).find("category").each(function(){								
		var myElementID = +$(this).find('id:first').text();
		if(myElementID==pcategory_id){
			mySubcategories = $(this).find('subcategories');
			if($.type(preturnlist)=="undefined" || 
			   $.type(preturnlist)=="null"){
				   $("#drop_down_list3").find("option").remove();
				   fill_in_dropdownlists("drop_down_list3",mySubcategories);
			}
		}
	});
	displaydescription();
	return mySubcategories;
}

function fill_in_dropdownlists(pdrop_down_list_name, poptions){
	$(poptions).children().each(function() {        
		var myElementID = +$(this).find('id:first').text();
     	var myElementName = $(this).find('name:first').text();
      	$("#"+pdrop_down_list_name).append(
		  "<option value="+myElementID+">"+myElementName+"</option>");
	});	
}

function loadXML(){		
	var result="";
	/*p = {
			    parameter1 : "USA",
					parameter2 : "1",
					parameter3 : "AZ"
					
		}*/
	
	$.ajax({
		type: "GET",
		url: "xml/combos.xml",
		dataType: "xml",
		//data: JSON.stringify(p),
		async:false, //controller
		success: function(data){
			result=data;
		}
	});
	return result;
}

function displaydescription(){
	var vOption1=$("#drop_down_list1 option:selected").text();
	var vOption2=$("#drop_down_list2 option:selected").text();
	var vOption3=$("#drop_down_list3 option:selected").text();
	vOption1=(vOption1!="")?"You have choosen: " + vOption1:"";
	vOption2=(vOption2!="")?", "+vOption2:"";	
	vOption3=(vOption3!="")?", "+vOption3:"";
	document.getElementById('msg').innerHTML=vOption1+vOption2+vOption3;
}